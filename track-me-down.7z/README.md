# React + Vite + Amplify

To override registry in __package-lock.json__, use:

```npm --registry https://registry.npmjs.org install```
